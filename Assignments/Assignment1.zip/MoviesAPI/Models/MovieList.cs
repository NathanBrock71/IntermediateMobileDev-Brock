﻿namespace MoviesAPI.Models
{
    public class MovieList
    {
        public List<Movie>? Movies { get; set; }
    }
}
